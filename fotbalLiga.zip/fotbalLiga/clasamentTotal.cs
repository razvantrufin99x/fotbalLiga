﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace fotbalLiga
{
    public class clasamentTotal
    {
        public List<clasament> clasamente = new List<clasament>();
    }
}
