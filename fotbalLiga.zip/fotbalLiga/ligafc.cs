﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace fotbalLiga
{
    public class ligafc
    {
        public meciuriliga meciurile = new meciuriliga();
        public List<echipa> echipe = new List<echipa>();
        public clasamentTotal clasamentul = new clasamentTotal();
    }
}
