﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace fotbalLiga
{
    public class meciuriliga
    {
        public List<meci> meciuri = new List<meci>();
    }
}
